---
filename_slug: article_ignition_history
title: "汽车点火系统发展史——从触点式到半导体点火 | HXO Resistor"
description: 汽车点火系统从触点式到半导体点火的100年演进史，抑制电阻角色随技术迭代的变化，以及现代车规IG电阻的技术定位。
keywords: "点火系统发展史,汽车点火技术演进,抑制电阻,半导体点火,点火线圈,触点式点火"
# 外壳：原页面固定结构，逐字保留（阶段2：不改变外观/埋点/Schema）
layout: legacy
shell_head: |
  <!DOCTYPE html>
  <html lang="zh-CN">
  <head>
  <!-- Clarity tracking code -->
  <script>
  (function(c,l,a,r,i,t,y){ c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)}; t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i; y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y); })(window, document, "clarity", "script", "xrcejtxzio");
  </script>
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-X6WNVWY7LC"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'G-X6WNVWY7LC');
  </script>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="description" content="汽车点火系统从触点式到半导体点火的100年演进史，抑制电阻角色随技术迭代的变化，以及现代车规IG电阻的技术定位。">
      <meta name="keywords" content="点火系统发展史,汽车点火技术演进,抑制电阻,半导体点火,点火线圈,触点式点火">
      <title>汽车点火系统发展史——从触点式到半导体点火 | HXO Resistor</title>
      <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.8; color: #333; max-width: 900px; margin: 0 auto; padding: 20px; background: #f9f9f9; }
          .header { background: linear-gradient(135deg, #1a1a2e, #16213e); color: white; padding: 40px 20px; text-align: center; margin-bottom: 30px; }
          .header h1 { font-size: 2em; margin-bottom: 10px; }
          .nav { background: #1a1a2e; padding: 15px; margin-bottom: 20px; }
          .nav a { color: #fff; text-decoration: none; margin-right: 20px; font-size: 14px; }
          .content { background: white; padding: 40px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
          table { width: 100%; border-collapse: collapse; margin: 15px 0; }
          th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
          th { background: #1a1a2e; color: white; }
          .highlight { background: #fff3cd; padding: 15px; border-left: 4px solid #ffc107; margin: 20px 0; }
          .timeline { background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #0f3460; }
          .timeline h3 { color: #0f3460; margin-bottom: 8px; }
          .cta { background: linear-gradient(135deg, #1a1a2e, #16213e); color: white; padding: 30px; border-radius: 8px; text-align: center; margin-top: 30px; }
          .btn { display: inline-block; background: #e94560; color: white; padding: 12px 30px; border-radius: 5px; text-decoration: none; margin: 10px; }
          .footer { text-align: center; padding: 30px; color: #666; font-size: 14px; }
      </style>
      <script type="application/ld+json">
      {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": "汽车点火系统发展史——从触点式到半导体点火",
        "description": "点火系统百年演进，抑制电阻角色随技术迭代的变化。",
        "author": { "@type": "Organization", "name": "HXO Resistor 技术团队" },
        "publisher": { "@type": "Organization", "name": "HXO Resistor", "url": "https://www.hxo-lcr.cn" },
        "datePublished": "2026-10-02",
        "mainEntityOfPage": "https://www.hxo-lcr.cn/article_ignition_history.html"
      }
      </script>
      <script type="application/ld+json">
      {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
          { "@type": "Question", "name": "触点式点火与现代半导体的本质区别？", "acceptedAnswer": { "@type": "Answer", "text": "触点式靠机械开合初级电路，触点寿命短（几千次开关就磨损）；半导体用 MOSFET/IGBT 开关，寿命 10 万次以上、响应 100x 快。" } },
          { "@type": "Question", "name": "为什么触点式点火需要更大阻值的抑制电阻？", "acceptedAnswer": { "@type": "Answer", "text": "触点断开瞬间的抖动电弧（bounce arc）比半导体关断更剧烈，需要阻值更大（8~20kΩ）的抑制电阻来阻尼高频振荡。" } },
          { "@type": "Question", "name": "现代电动车还有点火系统吗？", "acceptedAnswer": { "@type": "Answer", "text": "纯电动车（BEV）无火花塞点火系统，但混动（HEV）与 PHEV 的发动机部分仍需点火，IG 电阻需求依然旺盛。" } }
        ]
      }
      </script>
  </head>
  <body>
      <div class="nav">
          <a href="./index.html">首页</a>
          <a href="./products/ignition-coil.html">点火线圈抑制电阻</a>
          <a href="./products/otp-fuse.html">OTP 2合1保险丝电阻</a>
          <a href="./products/wirewound.html">高阻值绕线电阻</a>
          <a href="./comparison.html">产品对比</a>
          <a href="./order.html">询价</a>
      </div>

      <div class="header">
          <h1>汽车点火系统发展史</h1>
          <p>从触点式到半导体点火——抑制电阻的百年演进</p>
      </div>
meta_info: ""
shell_tail: |
  <div class="cta">
              <h3>从老车型到新平台，IG 系列全覆盖</h3>
              <p>不确定哪款合适？三大系列对比表 + AEC-Q200 报告 + 免费工程样品。</p>
              <a class="btn" href="./products/ignition-coil.html">三大主力系列目录</a>
              <a class="btn" href="./comparison.html">IG-C vs IG-F vs IG-S 对比</a>
          </div>

          <div class="footer">
              <p>© 2026 HXO Resistor / 华星欧电子（深圳）有限公司 — 专注点火线圈抑制电阻</p>
              <p>
                  <a href="./index.html">首页</a> ·
                  <a href="./article_ig_c_vs_ig_f.html">IG-C vs IG-F 选型</a> ·
                  <a href="./article_emi_suppression.html">EMI 抑制原理</a>
              </p>
          </div>
      </div>
  <script>
      (function(){
          var bp = document.createElement('script');
          var curProtocol = window.location.protocol.split(':')[0];
          if (curProtocol === 'https') {
              bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
          } else {
              bp.src = 'http://push.zhanzhang.baidu.com/push.js';
          }
          var s = document.getElementsByTagName("script")[0];
          s.parentNode.insertBefore(bp, s);
      })();
      </script>
  </body>
  </html>

---

:::raw
<div class="content">
        <div class="highlight">
            <strong>一句话总结：</strong>汽车点火系统历经 100 年从触点式→无触点式→半导体系三代演进，每一次技术跃迁都改变了对「点火线圈抑制电阻」的规格要求。HXO 三大主力系列 IG-C/IG-F/IG-S 恰好对应了三代技术的关键节点。
        </div>

        <h2>一、为什么研究点火系统历史？</h2>
        <p>因为<em>抑制电阻</em>不是独立的元器件——它是点火线圈里的"隐形保护件"，规格由点火系统类型直接决定。搞清楚技术演进史，才能选对电阻。</p>

        <h2>二、点火系统三时代</h2>

        <div class="timeline">
            <h3>1900~1960s · 触点式点火（Contact Ignition）</h3>
            <p>火花塞靠 <strong>分配器（Distributor）+ 触点</strong> 生成点火信号。触点物理开合，每次开合瞬间产生高频振动放电（bounce arc），必须靠一个大阻值电阻（8~20kΩ）串联在次级绕组来阻尼。</p>
            <p><strong>对应抑制电阻</strong>：次级 8~20kΩ，脉冲耐压 25kV+（触点电弧大）。这一时代是 <strong>IG-C 陶瓷芯</strong> 的用武之地，也是 HXO 三大主力系列里最通用的。</p>
        </div>

        <div class="timeline">
            <h3>1960~1980s · 无触点式（Sparkless / Contactless）</h3>
            <p>触点磨损问题催生无触点技术：磁电式（MAGNETO）+ 晶体管开关。触点消失后 bounce arc 大幅减轻，次级阻值可以下探到 <strong>4~8kΩ</strong>。</p>
            <p><strong>对应抑制电阻</strong>：次级 4.7~8.2kΩ（150°C 级），IG-C 通用。这一代开始出现 <strong>IG-F 玻纤芯</strong>——发动机舱振动环境下比陶瓷更抗振。</p>
        </div>

        <div class="timeline">
            <h3>1980s~至今 · 半导体系（Semiconductor Ignition）</h3>
            <p>三阶段：MOSFET → IGBT → 集成点火控制 IC（CPC/EMC 芯片）。</p>
            <ul>
                <li><strong>初级驱动</strong>：MOSFET/IGBT 替代触点，开关速度 100x 提升，PWM 调能</li>
                <li><strong>次级</strong>：高压脉冲 30~40kV（高转速、稀薄燃烧需要），需要 <strong>高脉冲耐压</strong>的抑制电阻</li>
                <li><strong>EMC 问题</strong>：开关频率高、di/dt 达数千 A/μs，EMI 更凶，抑制电阻必须做 <strong>AEC-Q200 完整级</strong></li>
            </ul>
            <p><strong>对应抑制电阻</strong>：次级 4.7~10kΩ（30~40kV 脉冲耐压、+350°C 考核），<strong>IG-S 陶瓷实心</strong> 是这一代的主力。</p>
        </div>

        <h2>三、每一代点火技术对应的 IG 系列</h2>
        <table>
            <tr><th>点火技术</th><th>年代</th><th>次级阻值</th><th>脉冲耐压</th><th>推荐系列</th></tr>
            <tr><td>触点式</td><td>1900-60s</td><td>8~20kΩ</td><td>25~30kV</td><td><strong>IG-C</strong> 陶瓷芯（性价比）</td></tr>
            <tr><td>无触点式</td><td>60s-80s</td><td>4.7~8.2kΩ</td><td>30kV</td><td><strong>IG-F</strong> 玻纤芯（抗振）</td></tr>
            <tr><td>半导体 MOSFET/IGBT</td><td>80s-</td><td>4.7~10kΩ</td><td>30~40kV</td><td><strong>IG-S</strong> 陶瓷实心（旗舰）</td></tr>
            <tr><td>稀薄燃烧 / 高转速</td><td>近 10 年</td><td>4.7~10kΩ</td><td>40kV+</td><td><strong>IG-S</strong> + 完整级 AEC-Q200</td></tr>
        </table>

        <h2>四、电动车时代点火系统会不会消失？</h2>
        <p><strong>不会。</strong></p>
        <ul>
            <li><strong>纯电动车（BEV）</strong>：无火花塞，确实没有点火系统</li>
            <li><strong>混动（HEV）/ 插电混动（PHEV）</strong>：发动机部分仍需要火花塞点火，IG 电阻需求不变</li>
            <li><strong>燃油车存量</strong>：全球燃油车保有量 13 亿+，寿命 10~15 年， aftermarket 维修市场 IG 电阻需求将持续 10 年+</li>
            <li><strong>赛用/高性能</strong>：赛车、摩托车、Kart 仍用高转速火花塞点火，对 40kV 级 IG-S 需求稳定</li>
        </ul>

        <h2>五、工程视角：从历史看今天的选型</h2>
        <p>如果你手上有一款 30 年前的旧发动机要维修：它多半是触点式，选 <strong>IG-C 8~20kΩ</strong>；如果是 1990 年代的无触点式，选 <strong>IG-F 4.7~8.2kΩ</strong>；如果是 2010 年后的车，选 <strong>IG-S 4.7~10kΩ、40kV 级</strong>。历史决定规格，选错电阻 = EMI 超标 + 缺火。</p>

        </div>
:::
