---
filename_slug: article_otp_fuse_resistor
title: RXF 1W 12Ω 221°C OTP Temperature Fuse Resistor
# 外壳：原页面固定结构，逐字保留（阶段2：不改变外观/埋点/Schema）
layout: legacy
shell_head: |
  <!DOCTYPE html>
  <html lang="zh-CN">
  <head>
  <!-- Clarity tracking code -->
  <script>
  (function(c,l,a,r,i,t,y){ c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)}; t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i; y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y); })(window, document, "clarity", "script", "xrcejtxzio");
  </script>
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-X6WNVWY7LC"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'G-X6WNVWY7LC');
  </script>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>RXF 1W 12Ω 221°C OTP Temperature Fuse Resistor</title>
      <style>
          body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
          .header { background: #1a1a2e; color: white; padding: 20px; text-align: center; }
          .specs { background: #f5f5f5; padding: 20px; margin: 20px 0; border-radius: 8px; }
          table { width: 100%; border-collapse: collapse; }
          th, td { padding: 10px; border-bottom: 1px solid #ddd; text-align: left; }
          th { background: #1a1a2e; color: white; }
          .cta { background: #e94560; color: white; padding: 20px; text-align: center; margin-top: 30px; }
      </style>
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": "HXO Resistor",
    "url": "https://www.hxo-lcr.cn/",
    "description": "HXO 点火线圈抑制电阻、OTP 2合1保险丝电阻、高阻值绕线电阻专业制造商，AEC-Q200 认证，CQC/UL 双认证，7-15天交付。"
  }
  </script>

  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": "RXF 1W 12Ω 221°C OTP Temperature Fuse Resistor",
    "description": "RXF 1W 12Ω 221°C OTP Temperature Fuse Resistor",
    "author": {"@type": "Organization", "name": "HXO Resistor", "url": "https://www.hxo-lcr.cn/"},
    "publisher": {"@type": "Organization", "name": "HXO Resistor", "url": "https://www.hxo-lcr.cn/"},
    "datePublished": "2026-10-02",
    "mainEntityOfPage": "https://www.hxo-lcr.cn/article_otp_fuse_resistor.html"
  }
  </script>

  </head>
  <body>
      <div class="header">
          <h1>RXF 1W 12Ω 221°C OTP Temperature Fuse Resistor</h1>
          <p>Dual Protection Solution for Chargers - CQC/UL Certified</p>
      </div>
meta_info: ""
shell_tail: |
  <div class="cta">
          <h3>Request Sample or Technical Support</h3>
          <p>Email: resistor@hxo-lcr.cn</p>
      </div>
      <!-- Baidu Auto Push JS -->
      <script>
      (function(){
          var bp = document.createElement('script');
          var curProtocol = window.location.protocol.split(':')[0];
          if (curProtocol === 'https') {
              bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
          } else {
              bp.src = 'http://push.zhanzhang.baidu.com/push.js';
          }
          var s = document.getElementsByTagName("script")[0];
          s.parentNode.insertBefore(bp, s);
      })();
      </script>
      </body>
  </html>

---

:::raw
<div class="specs">
        <h2>Key Specifications</h2>
        <table>
            <tr><th>Parameter</th><th>Value</th></tr>
            <tr><td>Rated Power</td><td>1W @ 25°C</td></tr>
            <tr><td>Resistance</td><td>12Ω (Standard), 3.3/4.7/10Ω (Custom)</td></tr>
            <tr><td>Action Temperature</td><td>221°C ±5%</td></tr>
            <tr><td>Insulation Resistance</td><td>≥1000 MΩ</td></tr>
            <tr><td>Certification</td><td>CQC/UL</td></tr>
        </table>
    </div>
:::
