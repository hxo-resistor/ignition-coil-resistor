---
filename_slug: article_4k7_vs_10k
title: "4.7kΩ vs 10kΩ：点火线圈抑制电阻阻值选择专业指南 | HXO Resistor"
description: 专业解析点火线圈抑制电阻4.7kΩ和10kΩ的阻值差异：EMI抑制效果对比（CISPR 25 Class 3标准）、点火能量损失计算、不同车型选型建议，附实测对比数据和行业标准引用。
keywords: "点火线圈抑制电阻,4.7kΩ,10kΩ,电阻阻值选择,EMI抑制,CISPR 25,ISO 8820,点火能量,抑制电阻选型"
canonical: https://www.hxo-lcr.cn/article_4k7_vs_10k.html
# 外壳：原页面固定结构，逐字保留（阶段2：不改变外观/埋点/Schema）
layout: nav
shell_head: |
  ﻿<!DOCTYPE html>
  <html lang="zh-CN">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="description" content="专业解析点火线圈抑制电阻4.7kΩ和10kΩ的阻值差异：EMI抑制效果对比（CISPR 25 Class 3标准）、点火能量损失计算、不同车型选型建议，附实测对比数据和行业标准引用。">
      <meta name="keywords" content="点火线圈抑制电阻,4.7kΩ,10kΩ,电阻阻值选择,EMI抑制,CISPR 25,ISO 8820,点火能量,抑制电阻选型">
      <title>4.7kΩ vs 10kΩ：点火线圈抑制电阻阻值选择专业指南 | HXO Resistor</title>
      <link rel="sitemap" type="application/xml" href="https://www.hxo-lcr.cn/sitemap.xml">
      <link rel="canonical" href="https://www.hxo-lcr.cn/article_4k7_vs_10k.html">
      <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; color: #1a1a2e; line-height: 1.7; background: #fff; }
          .nav { background: rgba(26, 26, 46, 0.98); position: fixed; top: 0; left: 0; right: 0; z-index: 1000; height: 64px; }
          .nav-inner { max-width: 1200px; margin: 0 auto; display: flex; align-items: center; justify-content: space-between; padding: 0 24px; height: 100%; }
          .nav-logo { font-size: 1.3em; font-weight: 800; color: #fff; text-decoration: none; }
          .nav-logo span { color: #e94560; }
          .nav-links { display: flex; gap: 6px; list-style: none; }
          .nav-links a { color: #ccc; text-decoration: none; font-size: 0.85em; padding: 8px 14px; border-radius: 6px; }
          .nav-links a:hover { color: #fff; background: rgba(233,69,96,0.15); }
          .nav-links a.active { color: #e94560; background: rgba(233,69,96,0.12); }
          .nav-toggle { display: none; background: none; border: none; color: #fff; font-size: 1.5em; cursor: pointer; }
          @media (max-width: 768px) {
              .nav-links { display: none; position: absolute; top: 64px; left: 0; right: 0; background: #1a1a2e; flex-direction: column; padding: 12px; }
              .nav-links.open { display: flex; }
              .nav-toggle { display: block; }
          }
          .article-header { background: linear-gradient(135deg, #1a1a2e, #0f3460); color: #fff; padding: 100px 24px 50px; text-align: center; }
          .article-header h1 { font-size: 1.8em; font-weight: 800; max-width: 800px; margin: 0 auto 10px; }
          .article-header .meta { color: #8899b4; font-size: 0.85em; }
          .article-header .breadcrumb { color: #7a8aa5; font-size: 0.8em; margin-bottom: 12px; }
          .article-header .breadcrumb a { color: #e94560; text-decoration: none; }
          .container { max-width: 800px; margin: 0 auto; padding: 50px 24px; }
          .container h2 { font-size: 1.3em; color: #0f3460; margin: 36px 0 12px; padding-bottom: 6px; border-bottom: 2px solid #e94560; }
          .container h3 { font-size: 1.1em; color: #e94560; margin: 24px 0 8px; }
          .container h4 { font-size: 1em; color: #1a1a2e; margin: 18px 0 6px; }
          .container p { margin-bottom: 14px; color: #444; }
          .container ul, .container ol { margin: 10px 0 16px 20px; }
          .container li { margin-bottom: 6px; color: #444; }
          .container strong { color: #1a1a2e; }
          .container blockquote { border-left: 4px solid #e94560; background: #f8f9fa; padding: 14px 20px; margin: 20px 0; border-radius: 0 8px 8px 0; }
          .container blockquote p { margin: 0; color: #333; }
          .highlight-box { background: #f8f9fa; border-left: 4px solid #e94560; padding: 18px 22px; border-radius: 0 8px 8px 0; margin: 20px 0; }
          .highlight-box p { margin: 0; color: #333; }
          .info-box { background: #e8f5e9; border-left: 4px solid #2e7d32; padding: 18px 22px; border-radius: 0 8px 8px 0; margin: 20px 0; }
          .info-box p { margin: 0; color: #1b5e20; }
          .warn-box { background: #fff3e0; border-left: 4px solid #e65100; padding: 18px 22px; border-radius: 0 8px 8px 0; margin: 20px 0; }
          .warn-box p { margin: 0; color: #bf360c; }
          .table-wrap { overflow-x: auto; margin: 20px 0; }
          table { width: 100%; border-collapse: collapse; border-radius: 8px; overflow: hidden; }
          th { background: #1a1a2e; color: #fff; padding: 10px 14px; text-align: left; font-size: 0.85em; }
          td { padding: 10px 14px; border-bottom: 1px solid #eee; font-size: 0.9em; }
          tr:nth-child(even) { background: #fafafa; }
          tr:hover { background: #fff5f5; }
          .toc { background: #f8f9fa; border-radius: 8px; padding: 20px 24px; margin: 20px 0; border: 1px solid #eee; }
          .toc h3 { color: #0f3460; margin-top: 0; }
          .toc ol { margin: 8px 0 0 18px; }
          .toc a { color: #0f3460; text-decoration: none; }
          .toc a:hover { color: #e94560; text-decoration: underline; }
          .cta { background: #f8f9fa; border-radius: 12px; padding: 28px; text-align: center; margin: 40px 0; border: 1px solid #eee; }
          .btn { display: inline-block; padding: 12px 28px; border-radius: 30px; text-decoration: none; font-weight: 600; font-size: 0.9em; background: #e94560; color: #fff; margin: 4px; }
          .btn:hover { background: #d63851; }
          .btn-secondary { background: #0f3460; }
          .btn-secondary:hover { background: #0a2540; }
          .back-link { display: inline-block; margin-top: 30px; color: #e94560; text-decoration: none; font-weight: 600; }
          .back-link:hover { text-decoration: underline; }
          .related-links { background: #f8f9fa; border-radius: 12px; padding: 24px; margin: 40px 0; border: 1px solid #eee; }
          .related-links h3 { color: #0f3460; margin-top: 0; font-size: 1.1em; }
          .related-links ul { list-style: none; padding: 0; margin: 10px 0 0; }
          .related-links li { padding: 4px 0; }
          .related-links a { color: #e94560; text-decoration: none; }
          .related-links a:hover { text-decoration: underline; }
          .footer { background: #1a1a2e; color: #888; text-align: center; padding: 32px 24px; font-size: 0.85em; }
          .footer a { color: #e94560; text-decoration: none; }
          .footer .footer-links { display: flex; flex-wrap: wrap; justify-content: center; gap: 16px; margin-bottom: 12px; }
          @media (max-width: 768px) {
              .article-header h1 { font-size: 1.4em; }
              .container { padding: 30px 16px; }
          }
      </style>

      <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "name": "首页",
        "item": "https://www.hxo-lcr.cn/"
      },
      {
        "@type": "ListItem",
        "position": 2,
        "name": "技术文章",
        "item": "https://www.hxo-lcr.cn/articles.html"
      },
      {
        "@type": "ListItem",
        "position": 3,
        "name": "4.7kΩ vs 10kΩ阻值选择",
        "item": "https://www.hxo-lcr.cn/article_4k7_vs_10k.html"
      }
    ]
  }
      </script>
      <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": "4.7kΩ vs 10kΩ：点火线圈抑制电阻阻值选择专业指南",
    "description": "专业解析点火线圈抑制电阻4.7kΩ和10kΩ的阻值差异，涵盖EMI抑制效果对比（CISPR 25 Class 3标准）、点火能量损失计算、不同车型选型建议，附实测对比数据表。",
    "articleBody": "本文深入分析点火线圈抑制电阻4.7kΩ和10kΩ两种常见阻值的技术差异，包括EMI抑制原理、RC低通滤波特性、点火能量损失计算、不同发动机类型（化油器/电喷/CDI/PEI）的选型建议。引用ISO 8820-5道路车辆熔断器标准、CISPR 25无线电干扰特性标准、AEC-Q200汽车级无源元件认证标准，提供HXO IG-C/IG-F/IG-S三大系列在不同阻值下的实测数据对比表。",
    "wordCount": 6800,
    "author": {
      "@type": "Organization",
      "name": "华星欧电子（深圳）有限公司",
      "url": "https://www.hxo-lcr.cn/"
    },
    "publisher": {
      "@type": "Organization",
      "name": "HXO Resistor",
      "logo": {
        "@type": "ImageObject",
        "url": "https://www.hxo-lcr.cn/product_overview.jpg"
      }
    },
    "datePublished": "2026-07-22",
    "dateModified": "2026-07-27",
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": "https://www.hxo-lcr.cn/article_4k7_vs_10k.html"
    },
    "about": {
      "@type": "Thing",
      "name": "点火线圈抑制电阻",
      "description": "一种用于抑制点火系统电磁干扰的高压电阻元件"
    },
    "mentions": [
      {"@type": "Thing", "name": "CISPR 25"},
      {"@type": "Thing", "name": "ISO 8820-5"},
      {"@type": "Thing", "name": "AEC-Q200"},
      {"@type": "Thing", "name": "SAE J551"}
    ]
  }
      </script>
      <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "4.7kΩ和10kΩ抑制电阻能通用吗？",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "大多数情况下可以通用，但有前提条件。化油器摩托车可以通用，差异几乎感觉不到。电喷车需谨慎，10kΩ替换4.7kΩ可能导致高速缺火。原厂标注10kΩ的车型用4.7kΩ替换会导致EMI超标。"
        }
      },
      {
        "@type": "Question",
        "name": "4.7kΩ和10kΩ的EMI抑制效果差多少？",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "根据CISPR 25标准测试，4.7kΩ可抑制60%~70%的高频振荡，10kΩ可抑制80%~90%。但更高的抑制效果也意味着更大的点火能量损失。"
        }
      },
      {
        "@type": "Question",
        "name": "如何快速判断原车用哪种阻值？",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "看原车火花塞帽内的电阻颜色编码。日系车（本田/雅马哈/铃木）多用4.7kΩ（绿色或蓝色标记），欧系车（比亚乔/标致）多用5kΩ~10kΩ（红色或黄色标记）。最准确的方法是用万用表测量原车阻值。"
        }
      }
    ]
  }
      </script>
      <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": "HXO Resistor - 点火线圈抑制电阻专业制造商",
    "alternateName": "华星欧电子（深圳）有限公司",
    "url": "https://www.hxo-lcr.cn/",
    "description": "专业点火线圈抑制电阻制造商，IG-C陶瓷芯、IG-F玻纤芯、IG-S陶瓷实心三大系列，AEC-Q200认证，7-15天交付",
    "inLanguage": ["zh-CN", "en"]
  }
      </script>
          <!-- Clarity tracking code -->
  <script>
  (function(c,l,a,r,i,t,y){ c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)}; t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i; y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y); })(window, document, "clarity", "script", "xrcejtxzio");
  </script>
  <!-- Google tag (gtag.js) - GA4 -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-X6WNVWY7LC"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'G-X6WNVWY7LC');
  </script>

  </head>
  <body>
  <nav class="nav">
      <div class="nav-inner">
          <a href="./" class="nav-logo">HXO<span>.</span></a>
          <button class="nav-toggle" onclick="document.querySelector('.nav-links').classList.toggle('open')">☰</button>
          <ul class="nav-links">
              <li><a href="./">首页</a></li><li><a href="./products/ignition-coil.html">点火线圈抑制电阻</a></li>
  <li><a href="./products/otp-fuse.html">OTP 2合1保险丝电阻</a></li>
  <li><a href="./products/wirewound.html">高阻值绕线电阻</a></li>
              
              
              
              <li><a href="./comparison.html">产品对比</a></li>
              <li><a href="./specifications.html">技术参数</a></li>
              <li><a href="./selection-guide.html">选型指南</a></li>
              <li><a href="./case-studies.html">客户案例</a></li>
              <li><a href="./standards.html">行业标准</a></li>
              <li><a href="./articles.html" class="active">技术文章</a></li>
              <li><a href="./faq.html">FAQ</a></li>
              <li><a href="./#inquiry">询价/联系</a></li>
          </ul>
      </div>
  </nav>
  <div class="article-header">
      <div class="breadcrumb"><a href="./">首页</a> › <a href="./articles.html">技术文章</a> › 4.7kΩ vs 10kΩ</div>
      <h1>4.7kΩ vs 10kΩ：点火线圈抑制电阻阻值选择专业指南</h1>
      <div class="meta">HXO Resistor 技术团队 · 选型指南 · 2026-07-27 · 约6800字</div>
  </div>
  <div class="container">
meta_info: ""
shell_tail: |
  </div>
  <div class="footer">
      <div class="footer-links">
          <a href="./">首页</a>
          <a href="./ig-c.html">IG-C</a>
          <a href="./ig-f.html">IG-F</a>
          <a href="./ig-s.html">IG-S</a>
          <a href="./comparison.html">产品对比</a>
          <a href="./specifications.html">技术参数</a>
          <a href="./articles.html">技术文章</a>
          <a href="./faq.html">FAQ</a>
          <a href="https://www.hxo-lcr.cn" target="_blank">官网</a>
          <a href="mailto:resistor@hxo-lcr.cn">resistor@hxo-lcr.cn</a>
      </div>
      <p>© 2026 HXO Resistor / 华星欧电子（深圳）有限公司 — 专注点火线圈抑制电阻</p>
  </div>
      <!-- Baidu Auto Push JS -->
      <script>
      (function(){
          var bp = document.createElement('script');
          var curProtocol = window.location.protocol.split(':')[0];
          if (curProtocol === 'https') {
              bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
          } else {
              bp.src = 'http://push.zhanzhang.baidu.com/push.js';
          }
          var s = document.getElementsByTagName("script")[0];
          s.parentNode.insertBefore(bp, s);
      })();
      </script>
      </body>
  </html>
---

:::raw
<div class="toc">
    <h3>📑 本文目录</h3>
    <ol>
        <li><a href="#intro">引言：一个常见但关键的问题</a></li>
        <li><a href="#principle">抑制电阻的EMI抑制原理</a></li>
        <li><a href="#comparison">4.7kΩ vs 10kΩ 全面对比</a></li>
        <li><a href="#test-data">实测对比数据（CISPR 25标准）</a></li>
        <li><a href="#scenarios">不同场景选型建议</a></li>
        <li><a href="#misconceptions">常见误区</a></li>
        <li><a href="#industry-standards">行业标准引用</a></li>
        <li><a href="#summary">总结与建议</a></li>
    </ol>
</div>
:::

:::raw
<h2 id="intro">一、引言：一个常见但关键的问题</h2>
:::

这是摩托车维修师傅和配件采购人员最常问的问题之一。4.7kΩ和10kΩ的抑制电阻，外形一样、引脚间距一样、价格也差不多，**到底能不能混着用？**

**直接结论：**大多数情况下可以通用，但有严格的前提条件。用错了可能影响发动机性能，严重时会导致ECU误判或高速缺火。本文将从EMI抑制原理、RC低通滤波特性、点火能量损失计算、实测数据对比和行业标准引用五个维度，给出专业、可操作的选型指导。

:::raw
<div class="info-box">
    <p><strong>💡 核心概念：</strong>抑制电阻的本质是构成一个RC低通滤波器，与点火线圈的寄生电容共同作用，滤除火花塞放电时产生的高频振荡（通常在1~100MHz范围），同时保留点火所需的直流分量。阻值越高，滤波效果越强，但点火能量损失也越大。</p>
</div>
:::

:::raw
<h2 id="principle">二、抑制电阻的EMI抑制原理</h2>
:::

### 2.1 RC低通滤波机制

点火线圈抑制电阻与点火系统的寄生电容（线圈分布电容C₀，通常为10~50pF）构成一个RC低通滤波器。其截止频率f_c = 1/(2πRC)。以4.7kΩ电阻和30pF寄生电容为例：

- **4.7kΩ：**f_c ≈ 1/(2π × 4700 × 30×10⁻¹²) ≈ 1.13 MHz
- **10kΩ：**f_c ≈ 1/(2π × 10000 × 30×10⁻¹²) ≈ 0.53 MHz

由于点火系统的高频振荡分量主要集中在1~100MHz范围，两种阻值均能有效抑制。但**10kΩ的截止频率更低，对中低频段EMI的抑制更彻底**，这也是其对EMI敏感车型更适用的理论依据。

### 2.2 点火能量损失计算

点火能量损失取决于电阻与火花塞间隙的电压分配。假设点火线圈次级开路电压为20kV，火花塞击穿电压为8kV，抑制电阻分压V_R = R/(R+R_gap) × V_total。对于4.7kΩ和10kΩ：

- **4.7kΩ：**能量损失约5%~8%，火花能量约92%~95%
- **10kΩ：**能量损失约10%~15%，火花能量约85%~90%

在正常工况下，5%~8%的能量损失差异对发动机性能影响不大。但在大负荷、高转速工况下，**10kΩ的额外能量损失可能导致混合气点燃可靠性下降**，表现为高速缺火。

:::raw
<h2 id="comparison">三、4.7kΩ vs 10kΩ 全面对比</h2>
:::

:::raw
<div class="table-wrap">
<table>
    <tr><th>对比维度</th><th>4.7kΩ</th><th>10kΩ</th><th>技术依据</th></tr>
    <tr><td>EMI抑制效果（30~100MHz）</td><td>60%~70%衰减</td><td>80%~90%衰减</td><td>CISPR 25 Class 3 测试</td></tr>
    <tr><td>RC截止频率</td><td>~1.13 MHz</td><td>~0.53 MHz</td><td>f_c = 1/(2πRC)</td></tr>
    <tr><td>点火能量损失</td><td>5%~8%</td><td>10%~15%</td><td>分压比计算</td></tr>
    <tr><td>适用点火系统</td><td>CDI/PEI通用</td><td>CDI/ECU可控</td><td>SAE J973 标准</td></tr>
    <tr><td>化油器车型</td><td>✅ 推荐</td><td>✅ 可通用</td><td>无ECU，EMI不敏感</td></tr>
    <tr><td>电喷车型（&lt;250cc）</td><td>✅ 优先推荐</td><td>⚠️ 可临时替代</td><td>注意怠速稳定性</td></tr>
    <tr><td>电喷车型（≥400cc）</td><td>✅ 推荐</td><td>❌ 可能导致高速缺火</td><td>点火能量不足</td></tr>
    <tr><td>带CAN总线车型</td><td>⚠️ 按原厂阻值</td><td>⚠️ 按原厂阻值</td><td>EMI极度敏感</td></tr>
    <tr><td>EMI敏感场景（音响/通讯）</td><td>⚠️ 抑制不足</td><td>✅ 推荐</td><td>CISPR 12 标准</td></tr>
    <tr><td>HXO推荐系列</td><td>IG-C/IG-S</td><td>IG-C/IG-F</td><td>参见参数表</td></tr>
</table>
</div>
:::

:::raw
<h2 id="test-data">四、实测对比数据（CISPR 25标准）</h2>
:::

以下数据基于HXO实验室在CISPR 25标准测试条件下，对IG-C系列4.7kΩ和10kΩ电阻的实际EMI抑制效果测试（测试环境：30MHz~100MHz频段，1m距离，准峰值检波）：

:::raw
<div class="table-wrap">
<table>
    <tr><th>测试频率</th><th>无抑制电阻</th><th>4.7kΩ IG-C</th><th>10kΩ IG-C</th><th>CISPR 25 Class 3限值</th></tr>
    <tr><td>30 MHz</td><td>72 dBμV</td><td>48 dBμV</td><td>42 dBμV</td><td>60 dBμV</td></tr>
    <tr><td>50 MHz</td><td>68 dBμV</td><td>44 dBμV</td><td>37 dBμV</td><td>56 dBμV</td></tr>
    <tr><td>75 MHz</td><td>65 dBμV</td><td>40 dBμV</td><td>33 dBμV</td><td>52 dBμV</td></tr>
    <tr><td>100 MHz</td><td>60 dBμV</td><td>36 dBμV</td><td>29 dBμV</td><td>48 dBμV</td></tr>
    <tr><td><strong>平均衰减量</strong></td><td>—</td><td><strong>24.3 dB</strong> (约67%)</td><td><strong>30.5 dB</strong> (约85%)</td><td>—</td></tr>
</table>
</div>
:::

:::raw
<div class="highlight-box">
    <p><strong>📊 数据分析：</strong>两种阻值均满足CISPR 25 Class 3限值要求。10kΩ在75MHz和100MHz频段表现更优，比4.7kΩ多约7dB的衰减量。对于需要满足CISPR 25 Class 2（更严格）的应用场景，10kΩ是更安全的选择。</p>
</div>
:::

### HXO三大系列对应阻值参数对比

:::raw
<div class="table-wrap">
<table>
    <tr><th>参数</th><th>IG-C 4.7kΩ</th><th>IG-C 10kΩ</th><th>IG-S 4.7kΩ</th><th>IG-F 10kΩ</th></tr>
    <tr><td>脉冲耐压</td><td>30kV</td><td>30kV</td><td>40kV</td><td>25kV</td></tr>
    <tr><td>连续工作电压</td><td>28kV</td><td>28kV</td><td>28kV</td><td>20kV</td></tr>
    <tr><td>工作温度</td><td>-55~+275°C</td><td>-55~+275°C</td><td>-55~+350°C</td><td>-55~+155°C</td></tr>
    <tr><td>额定功率</td><td>3W~5W</td><td>3W~5W</td><td>3W~5W</td><td>3W~5W</td></tr>
    <tr><td>TCR</td><td>±100~±300 ppm/°C</td><td>±100~±300 ppm/°C</td><td>-900±300 ppm/°C</td><td>±200~±500 ppm/°C</td></tr>
    <tr><td>绝缘电阻</td><td>≥1,000 MΩ</td><td>≥1,000 MΩ</td><td>≥1,000 MΩ</td><td>≥500 MΩ</td></tr>
    <tr><td>AEC-Q200</td><td>标准级 ✓</td><td>标准级 ✓</td><td>完整级 ✓</td><td>标准级 ✓</td></tr>
    <tr><td>参考单价（批量）</td><td>¥1.5~3.0</td><td>¥1.5~3.0</td><td>¥3.0~6.0</td><td>¥1.0~2.5</td></tr>
</table>
</div>
:::

:::raw
<h2 id="scenarios">五、不同场景选型建议</h2>
:::

### 5.1 通用替换场景

对于**化油器摩托车**（无ECU），4.7kΩ和10kΩ通用，差异几乎感觉不到。建议优先选4.7kΩ，覆盖绝大多数摩托车应用场景。

### 5.2 EMI敏感场景

对于车载音响系统、通讯设备或对EMI有严格要求的场景，**推荐10kΩ**，更强的EMI抑制效果可减少对电子设备的干扰。参考标准：CISPR 12（车辆整车无线电干扰特性）和CISPR 25（车载接收机保护）。

### 5.3 大排量/高转速场景

对于400cc以上大排量摩托车或高转速应用，建议**选5kΩ~6.8kΩ**，兼顾EMI抑制和点火能量。如需10kΩ，推荐使用IG-S系列（40kV脉冲耐压），确保高转速工况下的可靠性。

### 5.4 带CAN总线的现代车型

对EMI极度敏感，**必须严格按原厂阻值选用**，不可随意替换。建议使用万用表测量原车电阻值后采购。

### 5.5 快速判断方法

:::raw
<div class="highlight-box">
    <p><strong>⚡ 快速判断原车阻值：</strong></p>
    <p>• 看原车火花塞帽内的电阻颜色编码：日系车（本田/雅马哈/铃木）多用4.7kΩ（<strong>绿色或蓝色标记</strong>），欧系车（比亚乔/标致）多用5kΩ~10kΩ（<strong>红色或黄色标记</strong>）</p>
    <p>• 最准确的方法：<strong>拆下来用万用表测量原车阻值</strong>（详见<a href="./article_multimeter_test.html">万用表检测方法指南</a>）</p>
    <p>• 不确定时：选4.7kΩ，覆盖绝大多数摩托车应用</p>
</div>
:::

:::raw
<h2 id="misconceptions">六、常见误区</h2>
:::

### 误区1：阻值越大对发动机越好

**错误。**阻值越大，EMI抑制效果越好，但点火能量损失也越大。10kΩ比4.7kΩ多损失约5%~7%的点火能量。对于大排量、高压缩比发动机，这可能导致高速缺火。

### 误区2：4.7kΩ和10kΩ可以随时互换

**不完全正确。**化油器车确实可以，但电喷车（尤其带ECU氧传感器闭环控制的车型）对EMI敏感，随意换阻值可能导致ECU误判空燃比。

### 误区3：抑制电阻不重要，随便买一个就行

**错误。**普通电阻的脉冲耐压通常只有几百伏，而点火线圈抑制电阻需要承受30kV~40kV的脉冲高压。使用普通电阻会导致瞬间击穿，严重时损坏点火线圈。必须选用通过AEC-Q200认证的汽车级抑制电阻。

### 误区4：同阻值不同品牌可以互换

**基本正确，但需注意功率等级和温度等级。**规格相同的抑制电阻，在阻值、功率、温度等级都匹配的前提下可以互换。但低价杂牌电阻可能存在虚标功率、耐压不足等问题（详见[价格差异分析](./article_price_difference.html)）。

:::raw
<h2 id="industry-standards">七、行业标准引用</h2>
:::

本文涉及的阻值选择与测试方法均基于以下行业标准：

:::raw
<div class="table-wrap">
<table>
    <tr><th>标准编号</th><th>标准名称</th><th>与本内容的关联</th></tr>
    <tr><td><strong>ISO 8820-5</strong></td><td>道路车辆 — 熔断器 — 第5部分：带非绝缘管状熔断体的熔断器（用于点火系统电阻）</td><td>规定点火系统用电阻元件的尺寸、电气参数和测试方法</td></tr>
    <tr><td><strong>CISPR 25</strong>（第4版，2021）</td><td>用于保护车辆上接收机的无线电干扰特性 — 限值和测量方法</td><td>规定抑制电阻在30MHz~1GHz频段的EMI限值，本文测试数据基于此标准</td></tr>
    <tr><td><strong>CISPR 12</strong>（第7版，2021）</td><td>车辆、船舶和内燃发动机驱动装置的无线电干扰特性 — 限值和测量方法</td><td>整车级EMI测试标准，指导抑制电阻选型</td></tr>
    <tr><td><strong>SAE J551</strong></td><td>车辆和设备的电磁兼容性（EMC）性能限值和测量方法</td><td>规定整车EMC测试要求，抑制电阻需满足其限值</td></tr>
    <tr><td><strong>AEC-Q200</strong>（Rev E，2023）</td><td>汽车级无源元件应力测试鉴定认证</td><td>规定汽车电阻的可靠性测试要求，包括高压脉冲、温度循环、耐湿等</td></tr>
    <tr><td><strong>IEC 60068-2-14</strong></td><td>环境试验 — 第2-14部分：温度变化试验方法</td><td>规定电阻温度循环测试方法，用于验证抑制电阻的温度可靠性</td></tr>
</table>
</div>
:::

:::raw
<h2 id="summary">八、总结与建议</h2>
:::

:::raw
<div class="highlight-box">
    <p><strong>📌 选型速查表：</strong></p>
    <p>• <strong>通用替换：</strong>选4.7kΩ IG-C，覆盖90%以上摩托车应用</p>
    <p>• <strong>EMI敏感场景</strong>（车载音响/通讯设备）：选10kΩ IG-C或IG-S，更强抑制</p>
    <p>• <strong>大排量/高转速（≥400cc）：</strong>选5kΩ~6.8kΩ，兼顾EMI和点火能量</p>
    <p>• <strong>极端高温环境：</strong>选IG-S系列（350°C耐温），阻值按原厂规格</p>
    <p>• <strong>高振动环境：</strong>选IG-F系列（抗振性比陶瓷芯高30%），阻值4.7kΩ优先</p>
    <p>• <strong>不确定时：</strong>选原厂同阻值，或联系我们免费获取选型建议 → <a href="mailto:resistor@hxo-lcr.cn">resistor@hxo-lcr.cn</a></p>
</div>
:::

:::raw
<div class="cta">
    <p><strong>免费样品申请</strong></p>
    <p>不确定选哪个阻值？申请免费样品，实测验证后再批量采购</p>
    <a href="mailto:resistor@hxo-lcr.cn?subject=4.7kΩ%2F10kΩ%20选型咨询" class="btn">📧 发送邮件</a>
    <a href="tel:+8613510200650" class="btn btn-secondary">📞 拨打电话</a>
    <a href="./#inquiry" class="btn" style="background:#2e7d32;">📋 在线询价</a>
</div>
:::

:::raw
<div class="related-links">
    <h3>📖 相关阅读</h3>
    <ul>
        <li><a href="./article_multimeter_test.html">点火线圈抑制电阻怎么用万用表测量好坏？</a> — 检测方法完整指南</li>
        <li><a href="./article_burn_causes.html">点火线圈抑制电阻烧了是什么原因？4种常见故障分析</a> — 失效模式深度解析</li>
        <li><a href="./article_installation_guide.html">点火线圈抑制电阻安装注意事项与常见误区</a> — 安装指南完整版</li>
        <li><a href="./article_price_difference.html">点火线圈抑制电阻价格差距大吗？为什么价格差异那么大？</a> — 采购参考</li>
        <li><a href="./selection-guide.html">点火线圈抑制电阻选型指南：阻值、功率、温度系数怎么选？</a> — 综合选型</li>
        <li><a href="./comparison.html">IG-C / IG-F / IG-S 三大系列产品对比</a> — 产品参数对比</li>
    
                <li><a href="./glossary.html">术语表</a></li>
</ul>
</div>
:::

:::raw
<a href="./articles.html" class="back-link">← 返回技术文章列表</a>
:::
