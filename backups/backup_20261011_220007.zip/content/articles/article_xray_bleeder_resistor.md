---
filename_slug: article_xray_bleeder_resistor
title: "高压电阻在X光机中的应用：如何选择合适的泄放电阻 | HXO Resistor"
description: X光机高压电路断电后电容仍带电，泄放电阻是保护维修人员的关键安全器件。本文从X光机典型工况（50kV/100nF）出发，给出泄放阻值与功率的计算方法、IEC 61010安全标准依据，以及HXO HVW高压绕线泄放电阻的选型结论，避免选错阻值导致泄放超时或电阻烧毁。
keywords: "X光机,高压电阻,泄放电阻,电容放电,HVW,高压绕线电阻,IEC 61010,医疗设备电阻,安全泄放"
canonical: https://www.hxo-lcr.cn/article_xray_bleeder_resistor.html
# 外壳：原页面固定结构，逐字保留（阶段2：不改变外观/埋点/Schema）
layout: nav
shell_head: |
  <!DOCTYPE html>
  <html lang="zh-CN">
  <head>
  <!-- Clarity tracking code -->
  <script>
  (function(c,l,a,r,i,t,y){ c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)}; t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i; y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y); })(window, document, "clarity", "script", "xrcejtxzio");
  </script>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="description" content="X光机高压电路断电后电容仍带电，泄放电阻是保护维修人员的关键安全器件。本文从X光机典型工况（50kV/100nF）出发，给出泄放阻值与功率的计算方法、IEC 61010安全标准依据，以及HXO HVW高压绕线泄放电阻的选型结论，避免选错阻值导致泄放超时或电阻烧毁。">
      <meta name="keywords" content="X光机,高压电阻,泄放电阻,电容放电,HVW,高压绕线电阻,IEC 61010,医疗设备电阻,安全泄放">
      <title>高压电阻在X光机中的应用：如何选择合适的泄放电阻 | HXO Resistor</title>
      <link rel="canonical" href="https://www.hxo-lcr.cn/article_xray_bleeder_resistor.html">
  <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; color: #1a1a2e; line-height: 1.7; background: #fff; }
          .nav { background: rgba(26, 26, 46, 0.98); position: fixed; top: 0; left: 0; right: 0; z-index: 1000; height: 64px; }
          .nav-inner { max-width: 1200px; margin: 0 auto; display: flex; align-items: center; justify-content: space-between; padding: 0 24px; height: 100%; }
          .nav-logo { font-size: 1.3em; font-weight: 800; color: #fff; text-decoration: none; }
          .nav-logo span { color: #e94560; }
          .nav-links { display: flex; gap: 6px; list-style: none; }
          .nav-links a { color: #ccc; text-decoration: none; font-size: 0.85em; padding: 8px 14px; border-radius: 6px; }
          .nav-links a:hover { color: #fff; background: rgba(233,69,96,0.15); }
          .nav-links a.active { color: #e94560; background: rgba(233,69,96,0.12); }
          .nav-toggle { display: none; background: none; border: none; color: #fff; font-size: 1.5em; cursor: pointer; }
          @media (max-width: 768px) {
              .nav-links { display: none; position: absolute; top: 64px; left: 0; right: 0; background: #1a1a2e; flex-direction: column; padding: 12px; }
              .nav-links.open { display: flex; }
              .nav-toggle { display: block; }
          }
          .article-header { background: linear-gradient(135deg, #1a1a2e, #0f3460); color: #fff; padding: 100px 24px 50px; text-align: center; }
          .article-header h1 { font-size: 1.8em; font-weight: 800; max-width: 820px; margin: 0 auto 10px; }
          .article-header .meta { color: #8899b4; font-size: 0.85em; }
          .article-header .breadcrumb { color: #7a8aa5; font-size: 0.8em; margin-bottom: 12px; }
          .article-header .breadcrumb a { color: #e94560; text-decoration: none; }
          .container { max-width: 820px; margin: 0 auto; padding: 50px 24px; }
          .toc { background: #f5f7fa; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px 24px; margin: 0 0 30px; }
          .toc h3 { margin-bottom: 12px; font-size: 1em; }
          .toc ol { padding-left: 20px; }
          .toc li { margin: 6px 0; }
          .toc a { color: #0f3460; text-decoration: none; }
          h2 { color: #1a1a2e; font-size: 1.4em; margin: 34px 0 14px; border-left: 4px solid #e94560; padding-left: 14px; line-height: 1.4; }
          h3 { color: #0f3460; font-size: 1.1em; margin: 22px 0 10px; }
          p { margin-bottom: 14px; text-align: justify; }
          ul { margin: 0 0 16px 22px; }
          li { margin-bottom: 8px; }
          a { color: #e94560; }
          .table-wrap { overflow-x: auto; margin: 20px 0; }
          table { width: 100%; border-collapse: collapse; font-size: 0.92em; }
          th, td { padding: 10px 12px; border-bottom: 1px solid #e2e8f0; text-align: left; }
          th { background: #1a1a2e; color: #fff; }
          tr:hover td { background: #f7f9fc; }
          .highlight-box { background: #fff5f5; border-left: 4px solid #e94560; padding: 16px 18px; margin: 20px 0; border-radius: 0 8px 8px 0; }
          .info-box { background: #e8f5e9; border-left: 4px solid #27ae60; padding: 16px 18px; margin: 20px 0; border-radius: 0 8px 8px 0; }
          .warn-box { background: #fff8e1; border-left: 4px solid #f39c12; padding: 16px 18px; margin: 20px 0; border-radius: 0 8px 8px 0; }
          .cta { background: linear-gradient(135deg, #1a1a2e, #0f3460); color: #fff; padding: 30px 24px; border-radius: 10px; margin: 36px 0; text-align: center; }
          .cta h2 { color: #fff; border: none; padding: 0; margin-top: 0; }
          .cta .btn { display: inline-block; background: #e94560; color: #fff; padding: 12px 26px; border-radius: 6px; text-decoration: none; font-weight: 700; margin: 8px 6px; }
          .cta .btn-secondary { background: transparent; border: 1px solid #e94560; }
          .related-links { background: #f5f7fa; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px 24px; margin: 20px 0; }
          .back-link { display: inline-block; margin: 10px 0; color: #0f3460; text-decoration: none; }
          .footer { background: #1a1a2e; color: #8899b4; padding: 30px 24px; text-align: center; font-size: 0.85em; margin-top: 40px; }
          .footer a { color: #ccc; text-decoration: none; margin: 0 6px; }
  </style>
  <script type="application/ld+json">
  {
   "@context": "https://schema.org",
   "@type": "BreadcrumbList",
   "itemListElement": [
    {"@type": "ListItem", "position": 1, "name": "首页", "item": "https://www.hxo-lcr.cn/"},
    {"@type": "ListItem", "position": 2, "name": "技术文章", "item": "https://www.hxo-lcr.cn/articles.html"},
    {"@type": "ListItem", "position": 3, "name": "高压电阻在X光机中的应用", "item": "https://www.hxo-lcr.cn/article_xray_bleeder_resistor.html"}
   ]
  }
  </script>
  <script type="application/ld+json">
  {
   "@context": "https://schema.org",
   "@type": "Article",
   "headline": "高压电阻在X光机中的应用：如何选择合适的泄放电阻",
   "description": "X光机高压电容断电后仍带电，泄放电阻保障维修人员安全。本文基于X光机典型工况50kV/100nF，给出泄放阻值与功率计算、IEC 61010依据，以及HXO HVW-5W-1MΩ-15kV选型结论。",
   "image": [
    "https://www.hxo-lcr.cn/product_overview.jpg"
   ],
   "datePublished": "2026-10-14",
   "dateModified": "2026-10-14",
   "author": {"@type": "Organization", "name": "HXO Resistor", "url": "https://www.hxo-lcr.cn/"},
   "publisher": {
    "@type": "Organization",
    "name": "HXO Resistor",
    "logo": {"@type": "ImageObject", "url": "https://www.hxo-lcr.cn/product_overview.jpg"}
   },
   "mainEntityOfPage": {"@type": "WebPage", "@id": "https://www.hxo-lcr.cn/article_xray_bleeder_resistor.html"},
   "mentions": [
    {"@type": "Thing", "name": "HVW 高压绕线泄放电阻"},
    {"@type": "Thing", "name": "X光机高压电容"},
    {"@type": "Thing", "name": "IEC 61010"}
   ]
  }
  </script>
  <script type="application/ld+json">
  {
   "@context": "https://schema.org",
   "@type": "FAQPage",
   "mainEntity": [
    {
     "@type": "Question",
     "name": "X光机为什么需要泄放电阻？",
     "acceptedAnswer": {"@type": "Answer", "text": "X光机高压发生器会产生数十kV电压并给主电容充电。断电后电容仍储存大量能量，若无泄放电阻，维修人员触碰高压端可能触电。泄放电阻在断电后1秒内将电压降至60V以下（IEC 61010安全阈值），是医疗设备的必备安全器件。"}
    },
    {
     "@type": "Question",
     "name": "X光机泄放电阻的阻值怎么定？",
     "acceptedAnswer": {"@type": "Answer", "text": "目标1秒泄放到60V以内：R≤1/(C·ln(V₀/60))。X光机典型工况 V₀=50kV、C=100nF，R≤1/(1e-7·ln(50000/60))≈1/(1e-7·6.73)≈1.49MΩ 是阻值上限——X光机电容为nF级，取1MΩ（低于上限）即可在断电后快速泄放到安全电压，同时避免正常工作时持续消耗过大功率，推荐 HVW-5W-1MΩ-15kV。"}
    },
    {
     "@type": "Question",
     "name": "X光机泄放电阻需要什么耐压等级？",
     "acceptedAnswer": {"@type": "Answer", "text": "X光机高压端峰值可达50kV以上，泄放电阻长期并联在高压电容两端，必须选耐压≥15kV的高压绕线型（HXO HVW-15kV），普通玻璃釉电阻（耐压<5kV）无法承受，且绝缘裕量不足。绝缘电阻≥1000MΩ、漏电流<1μA是硬指标。"}
    }
   ]
  }
  </script>
  <script type="application/ld+json">
  {
   "@context": "https://schema.org",
   "@type": "WebSite",
   "name": "HXO Resistor - 点火线圈电阻与放电电阻",
   "url": "https://www.hxo-lcr.cn/",
   "description": "HXO 提供 HVW 绕线电阻、IG 系列点火电阻与 RXF 温度保险电阻，交期 7-15 天。",
   "inLanguage": ["zh-CN", "en"]
  }
  </script>
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-X6WNVWY7LC"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'G-X6WNVWY7LC');
  </script>
  </head>
  <body>
  <nav class="nav">
      <div class="nav-inner">
          <a href="./" class="nav-logo">HXO<span>.</span></a>
          <button class="nav-toggle" onclick="document.querySelector('.nav-links').classList.toggle('open')">菜单</button>
          <ul class="nav-links">
              <li><a href="./">首页</a></li><li><a href="./products/ignition-coil.html">点火线圈抑制电阻</a></li>
  <li><a href="./products/otp-fuse.html">OTP 2合1保险丝电阻</a></li>
  <li><a href="./products/wirewound.html">高阻值绕线电阻</a></li>
              
              
              
              <li><a href="./comparison.html">产品对比</a></li>
              <li><a href="./specifications.html">规格参数</a></li>
              <li><a href="./selection-guide.html">选型指南</a></li>
              <li><a href="./case-studies.html">客户案例</a></li>
              <li><a href="./standards.html">标准认证</a></li>
              <li><a href="./articles.html" class="active">技术文章</a></li>
              <li><a href="./faq.html">FAQ</a></li>
              <li><a href="./#inquiry">询盘/联系</a></li>
          </ul>
      </div>
  </nav>
  <div class="article-header">
      <div class="breadcrumb"><a href="./">首页</a> › <a href="./articles.html">技术文章</a> › X光机高压泄放</div>
      <h1>高压电阻在X光机中的应用：如何选择合适的泄放电阻</h1>
      <div class="meta">HXO Resistor 技术部 · 高压安全 · 2026-10-14 · 约 1600 字</div>
  </div>
  <div class="container">
meta_info: ""
shell_tail: |
  </div>
  <div class="footer">
      <div class="footer-links">
          <a href="./">首页</a> <a href="./ig-c.html">IG-C</a> <a href="./ig-f.html">IG-F</a> <a href="./ig-s.html">IG-S</a>
          <a href="./comparison.html">产品对比</a> <a href="./specifications.html">规格参数</a> <a href="./articles.html">技术文章</a> <a href="./faq.html">FAQ</a>
          <a href="mailto:resistor@hxo-lcr.cn">resistor@hxo-lcr.cn</a>
      </div>
      <p>© 2026 HXO Resistor / 高压电阻在X光机中的应用：泄放电阻选型</p>
  </div>
  <script>
  (function(){
      var bp = document.createElement('script');
      var curProtocol = window.location.protocol.split(':')[0];
      if (curProtocol === 'https') {
          bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
      } else {
          bp.src = 'http://push.zhanzhang.baidu.com/push.js';
      }
      var s = document.getElementsByTagName('script')[0];
      s.parentNode.insertBefore(bp, s);
  })();
  </script>
  </body>
  </html>

---

:::raw
<div class="toc">
    <h3>本文目录</h3>
    <ol>
        <li><a href="#why">X光机高压电容为什么危险</a></li>
        <li><a href="#how">泄放电阻如何工作</a></li>
        <li><a href="#calc">阻值与功率怎么算</a></li>
        <li><a href="#spec">X光机选型关键参数</a></li>
        <li><a href="#trap">选型三个坑</a></li>
        <li><a href="#summary">结论</a></li>
    </ol>
</div>
:::

:::raw
<h2 id="why">X光机高压电容为什么危险</h2>
:::

X光机的高压发生器在工作时会把主电容充电到数十千伏，一次曝光脉冲的峰值电压可达 **50kV** 甚至更高。断电后，这只电容（连同分压电容）仍然带着高压电荷，若没有泄放通道，电压会维持很长时间——维修人员一旦触碰高压初级/次级端，就可能发生严重触电事故。

:::raw
<div class="highlight-box"><p><strong>核心安全要求</strong>：IEC 61010 规定，断电后高压端应在安全时间内降至 <b>60V DC</b> 以下（低压系统）；X光机这类高压医疗设备通常按更严格的时间常数要求设计，目标是断电 1 秒内泄放到安全电压。泄放电阻就是承担这项工作的安全器件。</p></div>
:::

:::raw
<h2 id="how">泄放电阻如何工作</h2>
:::

泄放电阻是**永久并联**在高压电容两端的，无论设备是否工作都保持连接。它不参与正常工作电路，只在断电后成为电容储能的泄放通路：电容电压按时间常数 τ=RC 指数衰减，`V(t) = V₀·e^(-t/RC)`。选对 R 值，就能让电压在目标时间内跌到 60V 以下。

对 X光机这类「高电压、极小电容（nF 级）」的组合，电容本身储能有限，但电压极高，所以泄放电阻必须是**高耐压、高阻值、低漏电流**的绕线高压型，普通贴片或玻璃釉电阻既耐压不够、绝缘裕量也不足。

:::raw
<h2 id="calc">阻值与功率怎么算</h2>
:::

### 阻值：满足泄放时间

目标 1 秒内泄放到 60V：

`R ≤ 1 / (C · ln(V₀/60))`

:::raw
<div class="table-wrap">
<table>
    <tr><th>X光机工况</th><th>参数</th><th>计算</th></tr>
    <tr><td>主电容</td><td>V₀ = 50kV，C = 100nF</td><td>ln(50000/60) ≈ 6.73</td></tr>
    <tr><td>阻值上限</td><td>R ≤ 1/(C·ln(V₀/60)) = 1/(1e-7 · 6.73)</td><td>≈ 1.49MΩ（满足 1s/60V 的上限）</td></tr>
    <tr><td>实际选型</td><td>取 1MΩ（低于上限）</td><td><strong>RC≈0.1s，泄放快于目标，且 nF 级电容 + 高阻值使常耗极小</strong></td></tr>
</table>
</div>
:::

这里要特别注意 X光机与其他泄放场景（如变频器、充电桩，电容为 μF~mF 级）的差异：X光机主电容是 **100nF** 的 nF 级小电容，RC 时间常数极小，所以阻值上限约 1.49MΩ。工程上取 **1MΩ**（略低于上限、留余量），RC≈0.1s，断电后约 0.67s 即泄放到 60V，满足 IEC 61010 的 1s 目标；同时正因为电容小、阻值高，泄放电阻在工作态的常耗功率很低。

### 功率：为什么 5W 就够

关键在**占空比**：X光机的 50kV 高压只出现在曝光瞬间（单次几十到几百毫秒），两次曝光之间高压基本回落，泄放电阻并不长期被 50kV 持续加载。因此电阻功率要按**长时间平均**而不是峰值来定——即使某次放电瞬态功率很高，但占空比低、平均功耗很小。按曝光占空比估算并留约 2 倍余量，**5W** 级即可覆盖，故推荐 **HVW-5W-1MΩ-15kV**。若你的 X光机曝光频率很高或带连续高压，请提供占空比，我们会重新核算额定功率。

:::raw
<h2 id="spec">X光机选型关键参数</h2>
:::

:::raw
<div class="table-wrap">
<table>
    <tr><th>参数项</th><th>HVW-5W-1MΩ-15kV 规格</th><th>说明</th></tr>
    <tr><td>标称阻值</td><td><strong>1MΩ</strong></td><td>高阻值，适合 nF 级小电容</td></tr>
    <tr><td>额定功率</td><td><strong>5W</strong></td><td>覆盖脉冲常耗 + 余量</td></tr>
    <tr><td>耐压等级</td><td><strong>15kV</strong>（AC rms, 1min）</td><td>承受 50kV 脉冲峰值的绝缘裕量</td></tr>
    <tr><td>绝缘电阻</td><td>≥1000 MΩ @500V DC</td><td>高压安全硬性指标</td></tr>
    <tr><td>漏电流</td><td>&lt;1 μA @额定电压</td><td>低漏电，避免干扰与常耗</td></tr>
    <tr><td>认证</td><td>IEC 61010 / GB 4793 符合</td><td>医疗设备安全标准</td></tr>
    <tr><td>安装</td><td>接线端子 / 面板安装</td><td>高压端安全接线</td></tr>
</table>
</div>
:::

:::raw
<h2 id="trap">选型三个坑</h2>
:::

- **坑1｜用低耐压玻璃釉电阻**：普通玻璃釉耐压 <5kV，X光机 50kV 峰值下长期工作绝缘裕量严重不足，有击穿风险。必须用 15kV 高压绕线型。
- **坑2｜阻值取得比上限还低，常耗发热**：若把阻值压得远低于 1.49MΩ 上限（如几十Ω），工作态 P=V²/R 会显著上升、电阻长期发热降额。X光机 nF 级小电容场景取 1MΩ 即可，无需更低。
- **坑3｜漏电流不达标**：X光机对精度与漏电敏感，漏电流 >1μA 会引入误差与常耗。选低漏电设计并做 100% 全检的产品。

:::raw
<div class="warn-box"><p><strong>提示</strong>：X光机泄放电阻建议同时做 <b>冗余并联</b>——用两颗同规格 1MΩ 电阻并联，阻值减半、泄放更快，单颗开路时另一颗仍可正常泄放，显著提升维修安全冗余。具体并联方案见 <a href="./selection-guide.html">选型指南</a>。</p></div>
:::

:::raw
<h2 id="summary">结论</h2>
:::

X光机的泄放电阻是**「高耐压 + 高阻值 + 低漏电」**的组合要求：主电容 100nF、高压 50kV 的典型工况下，推荐 **HXO HVW-5W-1MΩ-15kV** 高压绕线泄放电阻，断电 1 秒内把电压泄放到 IEC 61010 安全阈值以下，同时待机常耗极小。选型核心是「先确认高压峰值与电容值，再定 15kV 耐压 + 1MΩ 高阻值 + 5W 功率」，不要只看普通电阻的标称参数。

:::raw
<div class="cta">
    <h2>不确定 X光机该选多大的泄放电阻</h2>
    <p>把高压发生器峰值电压、主/分压电容值、曝光占空比发给我们，HXO 出泄放计算 + 15kV 定制方案（含冗余并联建议）。</p>
    <a href="./#inquiry" class="btn">索取选型方案</a>
    <a href="./order.html" class="btn btn-secondary">查看订单入口</a>
</div>
:::

:::raw
<div class="related-links">
    <h3>延伸阅读</h3>
    <ul>
        <li><a href="./article_discharge_calculation.html">泄放电阻计算指南：变频器制动系统完整选型方法</a></li>
        <li><a href="./article_ev_pile_bleeder.html">新能源充电桩电容泄放电阻选型</a></li>
        <li><a href="./article_hvw_braking.html">HVW 高阻值绕线电阻在变频器制动系统中的应用</a></li>
        <li><a href="./article_4k7_vs_10k.html">4.7kΩ vs 10kΩ：点火线圈抑制电阻阻值选择专业指南</a></li>
    </ul>
</div>
:::

:::raw
<a href="./articles.html" class="back-link">‹ 返回技术文章列表</a>
:::
